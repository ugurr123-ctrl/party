# Party Box - Tam Mobil & Web Proje Kaynak Kodları

Bu paket, Party Box uygulamasının tüm ön yüz, oyun motorları, ses sentezleyicisi ve mağaza yayınlama ayarlarını eksiksiz olarak içerir.

## Proje Bilgileri
- Uygulama Adı: Party Box
- Paket Kimliği (Bundle ID): com.partybox.app
- Kategori: Oyunlar / Parti / Masa Oyunları
- Mağaza Logoları: public/assets/icons/ klasöründe Google Play ve App Store için 1024x1024 boyutunda mevcuttur.
- Gizlilik Politikası: public/privacy-policy.html

## 1. Geliştirme Ortamında Çalıştırma
npm install
npm run dev

## 2. Google Play Store İçin Android APK / AAB Çıkarma
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
Android Studio'da: Build -> Generate Signed Bundle / APK -> Android App Bundle seçip Google Play Console'a yükleyin.

## 3. Apple App Store İçin iOS IPA Çıkarma (Mac Gerektirir)
npm run build
npx cap add ios
npx cap sync ios
npx cap open ios
Xcode'da: Product -> Archive -> Distribute App -> App Store Connect.

## Zorunlu Mağaza Linkleri
- Gizlilik Politikası (Privacy Policy URL):
  https://ais-pre-kb7ewp2gca55bbfaraukgk-848124876637.europe-west2.run.app/privacy-policy.html
- Destek / İletişim (Support URL):
  https://ais-pre-kb7ewp2gca55bbfaraukgk-848124876637.europe-west2.run.app/privacy-policy.html
